# platform-starter

Libreria unica per tutte le applicazioni Spring Boot: **contesto condiviso** (userId, requestId, ...)
e **logging uniforme**. Si attiva da sola aggiungendo la dipendenza.

## Struttura

```
com.example.platform
├── context/        PlatformContext (ThreadLocal), PlatformHeaders (contratto), ContextFilter (ingresso)
├── propagation/    interceptor RestClient, filtro WebClient, TaskDecorator per @Async
├── logging/        MdcLoggingFilter (MDC + log di ogni richiesta)
└── autoconfigure/  una @AutoConfiguration per area + PlatformProperties
```

Regola: `logging` dipende da `context`, mai il contrario. Il contesto e' la fonte di verita',
l'MDC e' solo una sua vista.

## Installazione

```
mvn clean install
```

Nell'applicazione:

```xml
<dependency>
    <groupId>com.example</groupId>
    <artifactId>platform-starter</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

Per condividerla con altri (team, CI) pubblicala con `mvn deploy` su Nexus/Artifactory/GitHub Packages.

## Configurazione (tutto opzionale)

```properties
platform.context.enabled=true
platform.context.headers=X-Request-Id,X-User-Id,X-Tenant-Id
platform.context.generate-request-id=true

platform.logging.enabled=true
platform.logging.log-requests=true
platform.logging.exclude-paths=/actuator/**

platform.propagation.enabled=true
```

Le chiavi MDC derivano dal nome dell'header: `X-Request-Id` -> `requestId`, `X-User-Id` -> `userId`,
`X-Tenant-Id` -> `tenantId`. L'URL e' nella chiave `url`.

## Formato dei log (nell'applicazione)

Testo:

```properties
logging.pattern.console=%d{HH:mm:ss.SSS} %-5level [%X{url:-}] [%X{requestId:-}] [%X{userId:-}] %logger{36} - %msg%n
```

JSON strutturato (consigliato su Kubernetes), le chiavi MDC compaiono come campi:

```properties
logging.structured.format.console=ecs
```

## Uso del contesto

```java
String user = PlatformContext.userId().orElse("anonymous");
```

## Chiamate in uscita

```java
// RestClient
RestClient client = RestClient.builder()
        .requestInterceptor(contextPropagationInterceptor)   // bean della libreria
        .build();

// WebClient
WebClient webClient = WebClient.builder()
        .filter(contextExchangeFilter)                       // bean della libreria
        .build();
```

`@Async`: il `TaskDecorator` e' un bean; Spring Boot lo applica all'executor che costruisce.
Se definisci un tuo `ThreadPoolTaskExecutor`, imposta `executor.setTaskDecorator(decorator)`.

## Note di sicurezza

- Header come `X-User-Id` sono falsificabili dal client: il **gateway** deve scartare quelli in ingresso
  dall'esterno e impostarli lui, oppure ricava l'utente dal JWT / SecurityContext.
- Vengono letti solo gli header in whitelist (`platform.context.headers`): non aggiungere mai
  `Authorization` o `Cookie`.
- I nomi degli header sono un contratto pubblico: modificarli richiede una nuova versione major.

## Personalizzazione

Ogni bean e' `@ConditionalOnMissingBean`: l'applicazione puo' definire un proprio `ContextFilter`,
`MdcLoggingFilter` ecc. per sostituire quello della libreria.
