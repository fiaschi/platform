package com.example.platform.propagation;

import com.example.platform.context.PlatformContext;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;
import java.util.Map;

/**
 * Per RestClient/RestTemplate: inoltra il contesto corrente come header nelle chiamate in uscita.
 * Non sovrascrive header gia' impostati esplicitamente.
 */
public class ContextPropagationInterceptor implements ClientHttpRequestInterceptor {

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body,
                                        ClientHttpRequestExecution execution) throws IOException {
        for (Map.Entry<String, String> entry : PlatformContext.getAll().entrySet()) {
            if (!request.getHeaders().containsHeader(entry.getKey())) {
                request.getHeaders().add(entry.getKey(), entry.getValue());
            }
        }
        return execution.execute(request, body);
    }
}
