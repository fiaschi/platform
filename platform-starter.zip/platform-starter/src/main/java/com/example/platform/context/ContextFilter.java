package com.example.platform.context;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.core.Ordered;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

/**
 * Legge gli header configurati dalla richiesta in ingresso e popola il {@link PlatformContext}.
 * Se manca X-Request-Id lo genera e lo restituisce anche nella risposta.
 */
public class ContextFilter extends OncePerRequestFilter implements Ordered {

    public static final int ORDER = Ordered.HIGHEST_PRECEDENCE + 10;

    private final List<String> headers;
    private final boolean generateRequestId;

    public ContextFilter(List<String> headers, boolean generateRequestId) {
        this.headers = headers;
        this.generateRequestId = generateRequestId;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        Map<String, String> values = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for (String header : headers) {
            String value = request.getHeader(header);
            if (value != null && !value.isBlank()) {
                values.put(header, value);
            }
        }
        if (generateRequestId && !values.containsKey(PlatformHeaders.REQUEST_ID)) {
            values.put(PlatformHeaders.REQUEST_ID, UUID.randomUUID().toString());
        }
        if (values.containsKey(PlatformHeaders.REQUEST_ID)) {
            response.setHeader(PlatformHeaders.REQUEST_ID, values.get(PlatformHeaders.REQUEST_ID));
        }

        PlatformContext.set(values);
        try {
            chain.doFilter(request, response);
        } finally {
            PlatformContext.clear();
        }
    }

    @Override
    public int getOrder() {
        return ORDER;
    }
}
