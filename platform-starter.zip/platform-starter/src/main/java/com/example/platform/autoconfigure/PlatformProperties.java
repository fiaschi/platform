package com.example.platform.autoconfigure;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.List;

/**
 * Proprieta' configurabili dalle applicazioni (prefisso "platform").
 */
@ConfigurationProperties(prefix = "platform")
public class PlatformProperties {

    private final Context context = new Context();
    private final Logging logging = new Logging();
    private final Propagation propagation = new Propagation();

    public Context getContext() {
        return context;
    }

    public Logging getLogging() {
        return logging;
    }

    public Propagation getPropagation() {
        return propagation;
    }

    public static class Context {
        /** Abilita la lettura degli header in ingresso nel contesto condiviso. */
        private boolean enabled = true;
        /** Header da leggere dalla richiesta e salvare nel contesto. */
        private List<String> headers = new ArrayList<>(List.of("X-Request-Id", "X-User-Id"));
        /** Genera X-Request-Id se manca nella richiesta. */
        private boolean generateRequestId = true;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public List<String> getHeaders() {
            return headers;
        }

        public void setHeaders(List<String> headers) {
            this.headers = headers;
        }

        public boolean isGenerateRequestId() {
            return generateRequestId;
        }

        public void setGenerateRequestId(boolean generateRequestId) {
            this.generateRequestId = generateRequestId;
        }
    }

    public static class Logging {
        /** Abilita MDC (url + contesto) e log delle richieste. */
        private boolean enabled = true;
        /** Logga una riga a fine richiesta (metodo, url, status, durata). */
        private boolean logRequests = true;
        /** Percorsi (pattern Ant) da non loggare. */
        private List<String> excludePaths = new ArrayList<>(List.of("/actuator/**"));

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public boolean isLogRequests() {
            return logRequests;
        }

        public void setLogRequests(boolean logRequests) {
            this.logRequests = logRequests;
        }

        public List<String> getExcludePaths() {
            return excludePaths;
        }

        public void setExcludePaths(List<String> excludePaths) {
            this.excludePaths = excludePaths;
        }
    }

    public static class Propagation {
        /** Abilita la propagazione del contesto (RestClient, WebClient, @Async). */
        private boolean enabled = true;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }
}
