package com.example.platform.autoconfigure;

import com.example.platform.logging.MdcLoggingFilter;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * Registra il filtro che copia il contesto nell'MDC e logga le richieste.
 * Richiede che il contesto sia attivo (il logging dipende dal contesto, mai il contrario).
 */
@AutoConfiguration(after = PlatformContextAutoConfiguration.class)
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnProperty(prefix = "platform.logging", name = "enabled", matchIfMissing = true)
@EnableConfigurationProperties(PlatformProperties.class)
public class PlatformLoggingAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public MdcLoggingFilter platformMdcLoggingFilter(PlatformProperties properties) {
        PlatformProperties.Logging logging = properties.getLogging();
        return new MdcLoggingFilter(logging.isLogRequests(), logging.getExcludePaths());
    }
}
