package com.example.platform.logging;

import com.example.platform.context.ContextFilter;
import com.example.platform.context.PlatformContext;
import com.example.platform.context.PlatformHeaders;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Copia contesto e url nell'MDC (cosi' compaiono in tutti i log della richiesta)
 * e, a richiesta conclusa, logga metodo, url, status e durata.
 */
public class MdcLoggingFilter extends OncePerRequestFilter implements Ordered {

    public static final String MDC_URL = "url";

    private static final Logger log = LoggerFactory.getLogger("platform.request");

    private final boolean logRequests;
    private final List<String> excludePaths;
    private final AntPathMatcher matcher = new AntPathMatcher();

    public MdcLoggingFilter(boolean logRequests, List<String> excludePaths) {
        this.logRequests = logRequests;
        this.excludePaths = excludePaths;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();
        return excludePaths.stream().anyMatch(pattern -> matcher.match(pattern, path));
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        List<String> keys = new ArrayList<>();
        String url = request.getMethod() + " " + request.getRequestURI();
        MDC.put(MDC_URL, url);
        keys.add(MDC_URL);
        for (Map.Entry<String, String> entry : PlatformContext.getAll().entrySet()) {
            String key = PlatformHeaders.toKey(entry.getKey());
            MDC.put(key, entry.getValue());
            keys.add(key);
        }

        long start = System.nanoTime();
        try {
            chain.doFilter(request, response);
        } finally {
            if (logRequests) {
                long ms = (System.nanoTime() - start) / 1_000_000;
                log.info("{} -> {} ({} ms)", url, response.getStatus(), ms);
            }
            keys.forEach(MDC::remove);
        }
    }

    @Override
    public int getOrder() {
        // subito dopo il filtro del contesto
        return ContextFilter.ORDER + 10;
    }
}
