package com.example.platform.context;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

/**
 * Contesto condiviso della richiesta corrente (userId, requestId, ...).
 * E' la fonte di verita': l'MDC dei log e gli header in uscita ne sono solo una "vista".
 * Le chiavi sono i nomi degli header (case-insensitive).
 */
public final class PlatformContext {

    private static final ThreadLocal<Map<String, String>> HOLDER = new ThreadLocal<>();

    private PlatformContext() {
    }

    public static void set(Map<String, String> values) {
        Map<String, String> copy = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        if (values != null) {
            copy.putAll(values);
        }
        HOLDER.set(copy);
    }

    public static void put(String header, String value) {
        Map<String, String> current = HOLDER.get();
        if (current == null) {
            current = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            HOLDER.set(current);
        }
        current.put(header, value);
    }

    /** Copia immutabile di tutti i valori; mappa vuota se non c'e' contesto. */
    public static Map<String, String> getAll() {
        Map<String, String> current = HOLDER.get();
        if (current == null) {
            return Collections.emptyMap();
        }
        Map<String, String> copy = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        copy.putAll(current);
        return Collections.unmodifiableMap(copy);
    }

    public static Optional<String> get(String header) {
        Map<String, String> current = HOLDER.get();
        return current == null ? Optional.empty() : Optional.ofNullable(current.get(header));
    }

    public static Optional<String> requestId() {
        return get(PlatformHeaders.REQUEST_ID);
    }

    public static Optional<String> userId() {
        return get(PlatformHeaders.USER_ID);
    }

    public static void clear() {
        HOLDER.remove();
    }
}
