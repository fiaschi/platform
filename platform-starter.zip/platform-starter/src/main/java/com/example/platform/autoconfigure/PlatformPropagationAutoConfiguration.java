package com.example.platform.autoconfigure;

import com.example.platform.propagation.ContextExchangeFilter;
import com.example.platform.propagation.ContextPropagationInterceptor;
import com.example.platform.propagation.ContextTaskDecorator;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskDecorator;
import org.springframework.http.client.ClientHttpRequestInterceptor;

/**
 * Propagazione del contesto: chiamate HTTP in uscita e thread asincroni.
 *
 * Gli interceptor sono esposti come bean: l'applicazione li aggancia ai propri client, ad esempio
 * <pre>RestClient.builder().requestInterceptor(contextPropagationInterceptor)</pre>
 */
@AutoConfiguration(after = PlatformContextAutoConfiguration.class)
@ConditionalOnProperty(prefix = "platform.propagation", name = "enabled", matchIfMissing = true)
@EnableConfigurationProperties(PlatformProperties.class)
public class PlatformPropagationAutoConfiguration {

    /** Propaga contesto e MDC su @Async; Spring Boot lo applica agli executor che costruisce. */
    @Bean
    @ConditionalOnMissingBean(ContextTaskDecorator.class)
    public TaskDecorator platformContextTaskDecorator() {
        return new ContextTaskDecorator();
    }

    @Configuration(proxyBeanMethods = false)
    @ConditionalOnClass(ClientHttpRequestInterceptor.class)
    static class RestClientPropagationConfiguration {

        @Bean
        @ConditionalOnMissingBean
        public ContextPropagationInterceptor contextPropagationInterceptor() {
            return new ContextPropagationInterceptor();
        }
    }

    @Configuration(proxyBeanMethods = false)
    @ConditionalOnClass(name = "org.springframework.web.reactive.function.client.WebClient")
    static class WebClientPropagationConfiguration {

        @Bean
        @ConditionalOnMissingBean
        public ContextExchangeFilter contextExchangeFilter() {
            return new ContextExchangeFilter();
        }
    }
}
