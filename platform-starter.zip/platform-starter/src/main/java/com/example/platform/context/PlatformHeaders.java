package com.example.platform.context;

import java.util.Locale;

/**
 * Nomi degli header che formano il contratto tra i servizi.
 * Trattarli come API pubblica: cambiarli rompe tutte le applicazioni.
 */
public final class PlatformHeaders {

    public static final String REQUEST_ID = "X-Request-Id";
    public static final String USER_ID = "X-User-Id";

    private PlatformHeaders() {
    }

    /**
     * Ricava la chiave MDC dal nome dell'header:
     * X-Request-Id -> requestId, X-User-Id -> userId, X-Tenant-Id -> tenantId.
     */
    public static String toKey(String header) {
        String name = header.startsWith("X-") || header.startsWith("x-") ? header.substring(2) : header;
        StringBuilder sb = new StringBuilder();
        boolean upperNext = false;
        for (char c : name.toCharArray()) {
            if (c == '-' || c == '_') {
                upperNext = true;
            } else if (sb.length() == 0) {
                sb.append(Character.toLowerCase(c));
                upperNext = false;
            } else if (upperNext) {
                sb.append(Character.toUpperCase(c));
                upperNext = false;
            } else {
                sb.append(String.valueOf(c).toLowerCase(Locale.ROOT));
            }
        }
        return sb.toString();
    }
}
