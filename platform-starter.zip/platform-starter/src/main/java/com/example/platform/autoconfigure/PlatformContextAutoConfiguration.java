package com.example.platform.autoconfigure;

import com.example.platform.context.ContextFilter;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * Registra il filtro che popola il contesto condiviso dagli header in ingresso.
 */
@AutoConfiguration
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnProperty(prefix = "platform.context", name = "enabled", matchIfMissing = true)
@EnableConfigurationProperties(PlatformProperties.class)
public class PlatformContextAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public ContextFilter platformContextFilter(PlatformProperties properties) {
        PlatformProperties.Context ctx = properties.getContext();
        return new ContextFilter(ctx.getHeaders(), ctx.isGenerateRequestId());
    }
}
