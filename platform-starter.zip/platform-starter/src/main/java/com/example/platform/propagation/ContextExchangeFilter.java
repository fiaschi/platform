package com.example.platform.propagation;

import com.example.platform.context.PlatformContext;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * Per WebClient: inoltra il contesto come header.
 * Va applicato nel punto in cui si costruisce la richiesta (thread chiamante):
 * <pre>WebClient.builder().filter(new ContextExchangeFilter())</pre>
 */
public class ContextExchangeFilter implements ExchangeFilterFunction {

    @Override
    public Mono<org.springframework.web.reactive.function.client.ClientResponse> filter(
            ClientRequest request, ExchangeFunction next) {
        Map<String, String> context = PlatformContext.getAll();
        if (context.isEmpty()) {
            return next.exchange(request);
        }
        ClientRequest.Builder builder = ClientRequest.from(request);
        context.forEach((name, value) -> {
            if (!request.headers().containsHeader(name)) {
                builder.header(name, value);
            }
        });
        return next.exchange(builder.build());
    }
}
